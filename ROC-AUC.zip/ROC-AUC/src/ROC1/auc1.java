package ROC1;

import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import ROC1.Trapezoid;

public class auc1 {

	        //将由键盘中输入的内容保存在指定的文件中
			public static boolean saveMessageToFile(String fileName) {  //保存信息到文件中
				
				File file = new File(fileName);  //新生成一个文件
				// 将数据按照文本输出到文件
				PrintWriter pw = null;  //将变量pw设置为null
				BufferedReader in = null;  //将变量in设置为null
				
				try {
					// 为输出文件建立一个写入器
					pw = new PrintWriter(new FileWriter(file));  //新生成一个写入器
					System.out.println("请输入文件的内容并输入end结束");  //控制台上输出相关提示信息
					// 用BufferedReader包装标准输入流
					in = new BufferedReader(new InputStreamReader(System.in));  //将字节流转换为字符流，并从字符输入流中读取文本 
					String inputLine = null;  //将变量inputline设置为null
					while (((inputLine = in.readLine()) != null)
							&& (!inputLine.equals("end"))) {
						pw.println(inputLine);
					}  //如果不为空且没有碰到"end"就继续输入
					pw.flush();  //将数据送出，刷新缓冲区
					pw.close();  //pw关闭
					return true;  //返回真
				} catch (IOException e) {  //捕获异常
					System.out.println(e.getMessage());  //输出异常信息
					return false;  //返回假
				} finally {
					if (in != null) {  //如果in不为null
						try {
							in.close();  //in关闭
						} catch (IOException e) {  //捕获异常
							e.printStackTrace();
						}
					}
				}
			}
			
			// 按照文件中格式将文件内容显示出来
			public static void readFileMessage(String fileName) {  
				
				File file = new File(fileName);
				BufferedReader reader = null;
				
				try {
					System.out.println("按顺序读取文件的内容如下：");
					reader = new BufferedReader(new FileReader(file));
					String string = null;
					int line = 1;
					// 按行读取内容，直到读入null则表示读取文件结束
					while ((string = reader.readLine()) != null) {
						System.out.println("line " + line + ": " + string);
						line++;
					}
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					if (reader != null) {
						try {
							reader.close();
						} catch (IOException e) {
						}
					}
				}
			}
			
			public static void confusionMatrix() {
				
				Scanner sc = new Scanner(System.in);
				
				try{
					int t = sc.nextInt();
					if (t < 0 || t > 20){
						System.out.println("请正常输入");
					}
					else{
						System.out.println("你输入的阈值的个数是:"+t);
					}
				} catch(Exception e) {
					System.out.println("请正常输入");
				}
				
				
			}
			
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        
        float[] a,b,h;
        try {
        	int c = sc.nextInt();
        	if (c < 0 || c > 10){
        		System.out.println("请正常输入");
        	}
        	else{
        		System.out.println("你输入的分类器的个数是:"+c);
        	}
        } catch (Exception e) {
        	System.out.println("请正常输入");
        }
        
        try {
        	int s = sc.nextInt();
        	if (s < 0 || s > 100){
        		System.out.println("请正常输入");
        	}
        	else{
        		System.out.println("你输入的样本的个数是:"+s);
        	}
        } catch (Exception e) {
        	System.out.println("请正常输入");
        }
        
        
        String fileName = "D:/ROC/AUC.txt";  //保存数据的文件的名称和路径
		auc1.saveMessageToFile(fileName);  //主函数调用TPRANDFPR1类中的saveMessageToFile(fileName)方法
		System.out.println(); 
		System.out.println("输出文件的内容:");
		auc1.readFileMessage(fileName);
		System.out.println();
	}

}
