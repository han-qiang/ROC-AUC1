package ROC1;

import java.util.Scanner;
public class Trapezoid {

	public static void main(String[] args) {
		
		int i = 0;
		double sum =0;
		// TODO Auto-generated method stub
        double[] a = {1.0,0.9,0.8,0.6,0.6,0.6,0.6,0.4,0.3,0.3,0.2,0.2,0.1,0.0};
        double[] b = {1.0,1.0,0.9,0.8,0.6,0.6,0.6,0.6,0.4,0.3,0.3,0.2,0.2,0.1};
        double[] h = {0.1,0.0,0.1,0.0,0.1,0.0,0.2,0.1,0.1,0.0,0.0,0.1,0.2,0.0};
        double[] S = {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
        
        for (i=0;i<14;i++){
        	S[i] = ((a[i]+b[i])*h[i])/2;
        }
        
        for (i=0;i<14;i++){
        	sum = sum+S[i];
        }
        
        System.out.println("请输出所有梯形面积的总和");
        System.out.println("计算得所有梯形面积的总和为:"+sum);
	}

}
