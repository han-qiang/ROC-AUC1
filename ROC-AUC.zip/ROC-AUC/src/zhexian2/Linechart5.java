package zhexian2;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Stroke;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import com.sun.prism.BasicStroke;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.chart.LineChart;
//import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

public class Linechart5 extends JPanel {
	
	public float BasicStroke(float width){
		return width;
		
	}
	
	Polygon po = new Polygon();
	Font fn = new Font("Times New Roman", Font.BOLD, 20);
	Font fn2 = new Font("宋体", Font.BOLD, 20);
	int x = 100;
	int y = 100;
	int[] pox = { 90, 100, 100 };
	int[] poy = { 20, 0, 10 };
	int[] poxx = { 100, 100, 110 };
	int[] poyy = { 0, 10, 20 };
	int[] poxB = { 980, 990, 1000 };
	int[] poyB = { 910, 900, 900 };
	int[] poxBB = { 980, 990, 1000 };
	int[] poyBB = { 890, 900, 900 };
	
	public Linechart5(){
	    setSize(1200, 1200);
	}
	
	public void paint(Graphics g){
	    super.paintComponent(g);
	    Graphics2D g2d = (Graphics2D) g;
	    g2d.setColor(Color.WHITE);  //填充黑色
	    g2d.fillRect(99, 0, 2, 900);
	    g2d.fillRect(99, 900, 900, 2);
	    //g2d.fillRect(100, 685, 15, 15);
	    for (int i = 0; i < 101; i++){
	        g2d.drawLine(100 + i * 9, 900, 100 + i * 9, 0);
	        g2d.drawLine(100, 900 - i * 9, 1000, 900 - i* 9);
	        g2d.drawString("0", x - 20, 920);
	        if (i % 2 == 0 && i / 2 != 0){
	            g2d.drawString(String.valueOf(i), 80, 910 - i * 9);
	            g2d.drawString(String.valueOf(i), x - 5 + i * 9, 910);
	        }
	    }
	    //g2d.setFont(fn2);
	    //g2d.setColor(Color.white);
	    //g2d.drawString("0", 102, 700);
	    g2d.setFont(fn);
	    g2d.setColor(Color.black);  //填充黑色
	    g2d.drawString("TPR", 80, 10);  //y轴名称
	    g2d.drawString("FPR", 990, 920);  //x轴名称
	    g2d.fillPolygon(pox,poy,3);  //y轴左侧箭头
	    g2d.fillPolygon(poxx,poyy,3);  //y轴右侧箭头
	    g2d.fillPolygon(poxB,poyB,3);  //x轴下方箭头
	    g2d.fillPolygon(poxBB,poyBB,3);  //x轴上方箭头
	    
	    g2d.setColor(Color.red);
	    g2d.drawLine(1000, 0, 1000, 90);
	    g2d.drawLine(1000, 90, 910, 180);
	    g2d.drawLine(910, 180, 910, 450);
	    g2d.drawLine(910, 450, 820, 540);
	    g2d.drawLine(820, 540, 730, 630);
	    g2d.drawLine(730, 630, 640, 630);
	    g2d.drawLine(640, 630, 280, 630);
	    g2d.drawLine(280, 630, 190, 810);
	    g2d.drawLine(190, 810, 190, 900);
	    g2d.setColor(Color.green);
	    g2d.drawLine(1000, 0, 910, 0);
	    g2d.drawLine(910, 0, 910, 90);
	    g2d.drawLine(910, 90, 910, 360);
	    g2d.drawLine(910, 360, 820, 360);
	    g2d.drawLine(820, 360, 640, 360);
	    g2d.drawLine(640, 360, 640, 450);
	    g2d.drawLine(640, 450, 460, 540);
	    g2d.drawLine(460, 540, 370, 720);
	    g2d.drawLine(370, 720, 190, 810);
	    g2d.setColor(Color.ORANGE);
	    g2d.drawLine(1000, 0, 910, 0);
	    g2d.drawLine(910, 0, 640, 0);
	    g2d.drawLine(640, 0, 370, 180);
	    g2d.drawLine(370, 180, 370, 360);
	    g2d.drawLine(370, 360, 280, 450);
	    g2d.drawLine(280, 450, 280, 450);
	    g2d.drawLine(280, 450, 190, 810);
	    g2d.drawLine(190, 810, 100, 810);
	    g2d.drawLine(100, 810, 100, 810);
	    g2d.dispose();
	    
	}
	
	public static void main(String[] args){
	    JFrame jf = new JFrame();
	    jf.setSize(1200, 1200);
	    jf.setVisible(true);
	    jf.setDefaultCloseOperation(3);
	    jf.getContentPane().add(new Linechart5());
	}
	
}
